import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit{
  public selectedIndex = 0;
  public appPages = [
    {
      title: 'home',
      url: '/tabs',
      icon: 'home'
    },
    {
      title: 'Contact',
      url: '/contact',
      icon: 'call'
    },
    {
      title: 'About',
      url: '/aboutus',
      icon: 'people'
    }
  ];

  constructor() {
    this.initializeApp();
  }

  initializeApp() {

  }

  ngOnInit() {
    const path=window.location.pathname.split('/')[1];
    console.log(path);
    if (path !== undefined) {
      this.selectedIndex = this.appPages.findIndex(page=>page.title.toLowerCase() === path.toLowerCase());
    }
  }
}
