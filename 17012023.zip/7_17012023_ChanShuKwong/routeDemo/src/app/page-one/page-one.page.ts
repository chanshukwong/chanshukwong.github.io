import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page-one',
  templateUrl: './page-one.page.html',
  styleUrls: ['./page-one.page.scss'],
})
export class PageOnePage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  redirectTo(){
    this.router.navigateByUrl('/page-two');
  }

}
