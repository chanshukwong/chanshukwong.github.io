import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'page-one',
    pathMatch: 'full'
  },
  {
    path: 'page-one',
    loadChildren: () => import('./page-one/page-one.module').then( m => m.PageOnePageModule)
  },
  {
    path: 'page-two',
    loadChildren: () => import('./page-two/page-two.module').then( m => m.PageTwoPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
