import { Component } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  public JSON_DATA = [
    {id:'1', name:'Caden1', address:'Rm A, 68/F, Block 1, Happy Garden, Tuen Mun.', tel:'9499-1234'},
    {id:'2', name:'Caden2', address:'Rm B, 68/F, Block 2, Happy Garden, Tuen Mun.', tel:'9499-1234'},
    {id:'3', name:'Caden3', address:'Rm C, 68/F, Block 3, Happy Garden, Tuen Mun.', tel:'9499-1234'},
    {id:'4', name:'Caden4', address:'Rm D, 68/F, Block 4, Happy Garden, Tuen Mun.', tel:'9499-1234'}
  ];

  constructor(private router:Router) {}
  public goToContactDetails(contact: any) {
    this.router.navigate(['/second-page',{Contact:JSON.stringify(contact)}]);
  }
 }
