import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-second-page',
  templateUrl: './second-page.page.html',
  styleUrls: ['./second-page.page.scss'],
})
export class SecondPagePage implements OnInit {

  public getContact: any = null;
  public contactDetails: any = null;
  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    this.getContact = this.route.params.subscribe(params=>{this.contactDetails = JSON.parse(params['Contact']);});
  }
}
