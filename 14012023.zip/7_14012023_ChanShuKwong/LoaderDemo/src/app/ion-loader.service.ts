import { Injectable } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { dismiss } from '@ionic/core/dist/types/utils/overlays';

@Injectable({
  providedIn: 'root'
})
export class IonLoaderService {
  constructor(public loadingController: LoadingController) { }
  
  simpleloader() {
    this.loadingController.create({
      message: 'Loading...', duration: 2000
    }).then((response)=>{response.present()})
  }
  
  dismissLoader() {
    this.loadingController.dismiss().then((response)=>{
      console.log('Loader closed!', response);
    }).catch((err)=>{
      console.log('Loader closed!', response);
    })
  }

  autoLoader() {
    this.loadingController.create({
      message: 'Loader hides after 3 seconds', duration: 3000
    }).then((response)=>{
      response.present();
      response.onDidDismiss().then((response)=>{
        console.log('Loader dismissed', response);
      })
    })
  }
  
  customLoader() {
    this.loadingController.create({
      message: 'Loader with custom style', duration: 2000, cssClass: 'loader-css-class', backdropDismiss:true
    }).then((res)=>{
        res.present();
    });
  }
}

// Simple loader